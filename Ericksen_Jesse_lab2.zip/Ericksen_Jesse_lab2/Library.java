/* Jesse Ericksen
   CSCI 241
   Lab #2
   
   This program represents a specification for the Library class which can hold data 
   for a collection of books.
   
   *Requires Book.java  */

public class Library {

   //Tests out methods within Library class
   public static void main(String[] args){
   
//       removeBook("32533535325");
//       Book Gatsby = new Book("123232412424", "F. Scott Fitzgerald" , "The Great Gatsby",  "Scribners", 1925, 1);
//       addBook(Gatsby);
//       System.out.println(Gatsby);
   
   }
   
   private Book[] books;
   private int size;


   //Library Constructor (Currently Default creates array of int size)
   public Library(int size){
//     Library[] library = new Library[size];
   
   }
   
   
   //Adds a book to the Library. Returns true if succesfull.
   //If book already exists in Library, returns false.
   public static boolean addBook(Book book){
   
      System.out.println("addBook method has been called.");
      return true;
   }
   
   //Removes a book from the library. Returns true if succesfull.
   //If book does not exist in Library, returns false. 
   public static boolean removeBook(String isbn){
      
      System.out.println("removeBook method has been called.");
      return true;
   }
   
   //Removes all books of a given year from the Library.
   //Returns the # of books removed.
   public static int removeByYear(int year){
   
      System.out.println("removeByYear method has been called.");
      return 0;
   }
   
   //Returns a book in Library given it's ISBN. 
   
   public static Book findBook(String isbn){
   
      System.out.println("findBook method has been called.");
      return null;
      
   }
   
   //Finds all books from a given author in Library.
   //Returns as an array of books.
   public static Book[] findAuthor(String author){
      
      System.out.println("findAuthor method has been called.");
      return null;
   }
   
   //Finds all editions of a book from its ISBN.
   //Returns them as an array of books.
   public static Book[] findEditions(String isbn){
      
      System.out.println("findEditions method has been called.");
      return null;
   }
   
   //Returns the total books kept in a Library.
   public static int bookCount(){
      
      System.out.println("bookCount method has been called.");
      return 0;
   }
   
   //Compares two books and returns a negative value if
   //first book comes before the second. Positive if after.
   public static int compareBooks(Book book1, Book book2){
   
      System.out.println("compareBooks method has been called.");
      return 0;
   }
   
   //Prints string representation of entire Library.
   public String toString(){
      
      return "null";
   }
   
   
}